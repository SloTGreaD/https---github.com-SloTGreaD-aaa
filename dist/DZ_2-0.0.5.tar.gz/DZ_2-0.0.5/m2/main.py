def greeting():
    print('Hello world')